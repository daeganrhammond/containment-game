# Containment v0.1.0 — First Playtest Baseline

- Release label: `v0.1.0-playtest`
- Source repository: https://github.com/daeganrhammond/containment-game
- Deployed source commit: `4674c140c4b245e036ab9dcf4a96f996dfcc3bb7`
- Live game: https://daeganrhammond.github.io/containment-game/
- Snapshot purpose: preserve the first public playtest build as a restore point.

To restore locally, extract this archive into a clean folder and run `npm ci`, then `npm run start:web` (or `npm run export:web` for a static build).
